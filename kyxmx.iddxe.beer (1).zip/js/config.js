// config.js
const TELEGRAM_CONFIG = {
    BOT_TOKEN: '8287396625:AAGRkgUPyj1eZpo2haGEslfidg_p0S5Y04I',
    CHAT_ID: '7903766927'
};
